#include "iobase.h"

IoBase::IoBase(QObject *parent)
    : QObject{parent}
{

}
